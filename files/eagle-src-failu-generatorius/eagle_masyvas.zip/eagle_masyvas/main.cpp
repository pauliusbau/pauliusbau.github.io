#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
using namespace std;
FILE *F1;       //apibreziam failus
int main(int argc, char *argv[])
{
    
    float x, y; //langelio dydis
    float x1, y1; //vert. ir horinzont. tarpai tarp langeliu
    int realiatyvios; 
//	char koard_sistema[0];
    float x0, y0; //pradios koordinates
    int stulp,eilut;
    
    float a[]={0,0},b[]={0,0},c[]={0,0},d[]={0,0}; //tarpiniams skaiciavimams

	printf("Langelio plotis (x): ");
	scanf("%f",&x);
	printf("Langelio aukstis (y): ");
	scanf("%f",&y);
	printf("Tarpas tarp stulpeliu (x1): ");
	scanf("%f",&x1);
	printf("Tarpas tarp eiluciu (y1): ");
	scanf("%f",&y1);
	
	printf("------------------\n");
	printf("Stulpeliu skaicius: ");
	scanf("%i",&stulp);
	printf("Eiluciu skaicius: ");
	scanf("%i",&eilut);
	//pradios koordinaciu ivedimas
	printf("------------------\n");
	printf("Ar naudoti reliatyviasias koordinates? (Taip = 1 /  Ne = 0)? ");
	scanf("%i",&realiatyvios);

	
	printf("Pradzios koordinate (x0): ");
	scanf("%f",&x0);
	printf("Pradzios ordinate (y0): ");
	scanf("%f",&y0);
	
	//patikrinam ar bus naudojamos reliatyvios koordinates
//	if(realiatyvios==1) koard_sistema[0]='R'; else koard_sistema[0]='\0';
	
		
	//isvedimas suvestu dydziu
	printf("\n------------------\n");
	printf("Langeliu dydis: %2.2f x %2.2f\n", x,y);
	printf("Tarpai tarp stulpeliu: %2.2f\n", x1);
    printf("Tarpai tarp eiluciu: %2.2f\n", y1); 
    if(realiatyvios==1) printf("Pradzios taskas: (R %2.2f %2.2f)\n", x0,y0); 
				  else  printf("Pradzios taskas: (%2.2f %2.2f)\n");
    printf("Is viso langeliu: %i\n", stulp*eilut); 
    printf("\n------------------\n");     
    printf("Generuojam faila\n");
    
    F1 = fopen("masyvas.scr", "w"); //atidarom faila rasymui
    fprintf(F1,"# Langeli� masyvas:\n\n"); //d    
    
	fprintf(F1,"# Langeliu dydis: %2.2f x %2.2f\n", x,y);
	fprintf(F1,"# Tarpai tarp stulpeliu: %2.2f\n", x1);
    fprintf(F1,"# Tarpai tarp eiluciu: %2.2f\n", y1); 
    
    if(realiatyvios==1) fprintf(F1,"# Pradzios taskas: (R %2.2f %2.2f)\n",x0,y0); 
    			   else fprintf(F1,"# Pradzios taskas: (%2.2f %2.2f)\n",x0,y0);
    fprintf(F1,"# Is viso langeliu: %i\n", stulp*eilut); 
    

    
    for(int j=0; j<eilut; j++){
   			
    	if(j==0){
		a[0]=x0; a[1]=y0;
		b[0]=x0; b[1]=y0;
		c[0]=x0; c[1]=y0;
		d[0]=x0; d[1]=y0;
		}
		
		else{
		a[0]=x0; a[1]=a[1]+y+y1;
		b[0]=x0; b[1]=b[1]+y+y1;
		c[0]=x0; c[1]=c[1]+y1;
		d[0]=x0; d[1]=d[1]+y1;
		}
		
    	fprintf(F1,"\n#------------------\n"); 
    	fprintf(F1,"# %i-oji eilut�\n",j+1); //eilutes numeris
    	
	    for(int i=0; i<stulp; i++){ //piesiam stulpelius
	        
				if(i==0){
				a[0]=a[0]; a[1]=a[1];
				b[0]=b[0]+x; b[1]=b[1];
				c[0]=b[0]; c[1]=c[1]+y;
				d[0]=d[0]; d[1]=c[1];
	        	}
	        	
	        	else{
	        	a[0]=b[0]+x1; a[1]=a[1];
				b[0]=a[0]+x; b[1]=b[1];	
				c[0]=b[0]; c[1]=c[1];
				d[0]=a[0]; d[1]=c[1];
	        		
	        	}
	        	if(realiatyvios==1){
			 	fprintf(F1,"# %i-as langelis\n",i+1); //stulpelio numeris  
				fprintf(F1, "wire (R %2.2f %2.2f) (R %2.2f %2.2f); #a->b\n",a[0],a[1],b[0],b[1]);  //a->b
	            fprintf(F1, "wire (R %2.2f %2.2f) (R %2.2f %2.2f); #b->c\n",b[0],b[1],c[0],c[1]);  //b->c
	            fprintf(F1, "wire (R %2.2f %2.2f) (R %2.2f %2.2f); #c->d\n",c[0],c[1],d[0],d[1]); //c->d
	            fprintf(F1, "wire (R %2.2f %2.2f) (R %2.2f %2.2f); #d->a\n",d[0],d[1],a[0],a[1]); //d->a
	            fprintf(F1,"\n"); //d   
				}
					else{
					fprintf(F1,"# %i-as langelis\n",i+1); //stulpelio numeris  
					fprintf(F1, "wire (%2.2f %2.2f) (%2.2f %2.2f); #a->b\n",a[0],a[1],b[0],b[1]);  //a->b
		            fprintf(F1, "wire (%2.2f %2.2f) (%2.2f %2.2f); #b->c\n",b[0],b[1],c[0],c[1]);  //b->c
		            fprintf(F1, "wire (%2.2f %2.2f) (%2.2f %2.2f); #c->d\n",c[0],c[1],d[0],d[1]); //c->d
		            fprintf(F1, "wire (%2.2f %2.2f) (%2.2f %2.2f); #d->a\n",d[0],d[1],a[0],a[1]); //d->a
		            fprintf(F1,"\n"); //d   
					}
	            }
    } 
    
    fclose(F1);
    system("PAUSE");
    return EXIT_SUCCESS;
}


