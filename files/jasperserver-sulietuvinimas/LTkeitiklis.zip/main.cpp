using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>



int main(int argc, char* argv[])
{
	char A[1024];
	bool lt;
	
        ifstream IN("duom.txt",ios::in); 
        ofstream OUT("rez.txt",ios::out);
        
        if(IN.fail()){
           cout<<"Klaida atidarant duomenu faila duom.txt"; return 0;}   
     
      cout<<"Tekstas is duom.txt:"<<endl;
  while (!IN.eof()){        // loop while extraction from file is possible
     
  
 	char c = IN.get();       // get character from file
    if(c=='�') {cout << "&#260;"; OUT << "&#260;"; lt=1;}
    else if(c=='�') {cout << "&#261;"; OUT << "&#261;"; lt=1;}
	else if(c=='�') {cout << "&#268;"; OUT << "&#268;"; lt=1;}
	else if(c=='�') {cout << "&#269;"; OUT << "&#269;"; lt=1;}
	else if(c=='�') {cout << "&#278;"; OUT << "&#278;"; lt=1;}
	else if(c=='�') {cout << "&#279;"; OUT << "&#279;"; lt=1;}
	else if(c=='�') {cout << "&#280;"; OUT << "&#280;"; lt=1;}
	else if(c=='�') {cout << "&#281;"; OUT << "&#281;"; lt=1;}
	else if(c=='�') {cout << "&#302;"; OUT << "&#302;"; lt=1;}
	else if(c=='�') {cout << "&#303;"; OUT << "&#303;"; lt=1;}
	else if(c=='�') {cout << "&#352;"; OUT << "&#352;"; lt=1;}
	else if(c=='�') {cout << "&#353;"; OUT << "&#353;"; lt=1;}
	else if(c=='�') {cout << "&#362;"; OUT << "&#362;"; lt=1;}
	else if(c=='�') {cout << "&#363;"; OUT << "&#363;"; lt=1;}
	else if(c=='�') {cout << "&#370;"; OUT << "&#370;"; lt=1;}
	else if(c=='�') {cout << "&#371;"; OUT << "&#371;"; lt=1;}
	else if(c=='�') {cout << "&#381;"; OUT << "&#381;"; lt=1;}
	else if(c=='�') {cout << "&#382;"; OUT << "&#382;"; lt=1;}
	
	else if(c=='�') {cout << "&quot;"; OUT << "&quot;"; lt=1;}
	else if(c=='�') {cout << "&quot;"; OUT << "&quot;"; lt=1;}
	
	else if(c=='"') {cout << "&quot;"; OUT << "&quot;"; lt=1;}
	else {c=c; lt=0;}
   
   	
    if (IN.good()){
      if(!lt){
	   cout << c;
       OUT << c;}}
      
     
       
   
  }

/*   
   
    while(!IN.eof()){
        IN.getline(A,1024);
        
           if(IN.fail()){
           cout<<"Klaida atidarant duomen� fail� nd6_duom.txt"; break;}
        cout<<A<<endl;
        OUT<<A<<endl;
 }
  */     
        IN.close();
        OUT.close();
}
